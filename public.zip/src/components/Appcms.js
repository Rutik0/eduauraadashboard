import React from 'react'

import {Navbar, Nav, NavItem, Button, Glyphicon} from 'react-bootstrap';
export default function Appcms() {
    return (
        <div>
            <Button>Appcms</Button>
            <h1>Coming Soon</h1>
        </div>
    )
}
