import React from 'react'

export default function Sales() {
    return (
        <div>
           <h1>Coming Soon</h1> 
        </div>
    )
}
