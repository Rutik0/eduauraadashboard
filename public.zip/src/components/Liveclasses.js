import React from 'react'

export default function () {
    return (
        <div>
            <h1>Coming Soon</h1>
        </div>
    )
}
